package com.mta.service;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.mta.Repo.InterviewStatusRepo;

//@Service
public class InterviewStatusService {
	
//	@Autowired
//	private InterviewStatusRepo repo;

}
